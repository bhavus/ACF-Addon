<?php

if ( !defined('ABSPATH') )
  die('-1');

// silence is golden